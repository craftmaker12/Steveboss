package com.steveboss.item;

import com.steveboss.BossConfig;
import com.steveboss.ModItems;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

/**
 * Shotgun: right-click fires one shot (hitscan, {@link BossConfig#SHOTGUN_DAMAGE} damage).
 * Every shot uses one Shotgun Shell from the inventory (Creative players do not use ammo).
 */
public class ShotgunItem extends Item {
    public ShotgunItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (user.getItemCooldownManager().isCoolingDown(this)) {
            return TypedActionResult.pass(stack);
        }
        if (!user.getAbilities().creativeMode && !takeAmmo(user)) {
            if (!world.isClient) {
                user.sendMessage(Text.literal("No ammo!").formatted(Formatting.RED, Formatting.BOLD), true);
            }
            return TypedActionResult.fail(stack);
        }
        if (world instanceof ServerWorld serverWorld) {
            fire(serverWorld, user);
        }
        user.getItemCooldownManager().set(this, BossConfig.SHOTGUN_COOLDOWN_TICKS);
        return TypedActionResult.success(stack, world.isClient());
    }

    private static boolean takeAmmo(PlayerEntity player) {
        PlayerInventory inv = player.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(ModItems.SHOTGUN_AMMO)) {
                s.decrement(1);
                return true;
            }
        }
        return false;
    }

    private static void fire(ServerWorld world, PlayerEntity user) {
        double range = BossConfig.SHOTGUN_RANGE;
        Vec3d start = user.getEyePos();
        Vec3d dir = user.getRotationVec(1.0F);
        Vec3d end = start.add(dir.multiply(range));

        // Stop at the first block in the way
        var blockHit = world.raycast(new RaycastContext(start, end, RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE, user));
        if (blockHit.getType() != HitResult.Type.MISS) {
            end = blockHit.getPos();
        }

        Box box = user.getBoundingBox().stretch(end.subtract(start)).expand(1.0);
        EntityHitResult hit = ProjectileUtil.raycast(user, start, end, box,
                e -> e != user && !e.isSpectator() && e.canHit() && e instanceof LivingEntity,
                start.squaredDistanceTo(end));
        if (hit != null) {
            end = hit.getPos();
            Entity target = hit.getEntity();
            target.damage(world.getDamageSources().playerAttack(user), (float) BossConfig.SHOTGUN_DAMAGE);
        }

        // Muzzle flash + smoke trail
        Vec3d muzzle = start.add(dir.multiply(1.2));
        world.spawnParticles(ParticleTypes.FLASH, muzzle.x, muzzle.y - 0.2, muzzle.z, 1, 0.0, 0.0, 0.0, 0.0);
        double length = start.distanceTo(end);
        for (double d = 1.5; d < length; d += 1.0) {
            Vec3d p = start.add(dir.multiply(d));
            world.spawnParticles(ParticleTypes.SMOKE, p.x, p.y - 0.1, p.z, 1, 0.05, 0.05, 0.05, 0.0);
        }
        world.playSound(null, user.getBlockPos(), SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.5F, 1.7F);
        world.playSound(null, user.getBlockPos(), SoundEvents.ITEM_CROSSBOW_SHOOT, SoundCategory.PLAYERS, 1.0F, 0.6F);
    }
}
