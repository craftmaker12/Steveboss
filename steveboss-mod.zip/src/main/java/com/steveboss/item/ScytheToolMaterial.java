package com.steveboss.item;

import net.minecraft.item.Items;
import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;

/** Total hit damage = 1 (hand) + 26 (material) + 3 (sword bonus) = 30. */
public class ScytheToolMaterial implements ToolMaterial {
    public static final ScytheToolMaterial INSTANCE = new ScytheToolMaterial();

    @Override
    public int getDurability() {
        return 6000;
    }

    @Override
    public float getMiningSpeedMultiplier() {
        return 10.0F;
    }

    @Override
    public float getAttackDamage() {
        return 26.0F;
    }

    @Override
    public int getMiningLevel() {
        return 4;
    }

    @Override
    public int getEnchantability() {
        return 20;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.ofItems(Items.NETHERITE_INGOT);
    }
}
