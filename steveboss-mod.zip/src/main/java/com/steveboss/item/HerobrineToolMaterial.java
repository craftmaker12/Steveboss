package com.steveboss.item;

import net.minecraft.item.Items;
import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;

/**
 * Material of the Herobrine Sword.
 * Total hit damage = 1 (hand) + material damage + sword bonus = 1 + 36 + 3 = 40.
 */
public class HerobrineToolMaterial implements ToolMaterial {
    public static final HerobrineToolMaterial INSTANCE = new HerobrineToolMaterial();

    @Override
    public int getDurability() {
        return 8000;
    }

    @Override
    public float getMiningSpeedMultiplier() {
        return 14.0F;
    }

    @Override
    public float getAttackDamage() {
        return 36.0F;
    }

    @Override
    public int getMiningLevel() {
        return 4;
    }

    @Override
    public int getEnchantability() {
        return 25;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.ofItems(Items.NETHERITE_INGOT);
    }
}
