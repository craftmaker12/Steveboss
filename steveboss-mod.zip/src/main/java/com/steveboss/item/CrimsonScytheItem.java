package com.steveboss.item;

import com.steveboss.BossConfig;
import com.steveboss.entity.ScytheRingEntity;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.List;

/**
 * Crimson Scythe:
 * - every hit sets the target on fire, makes it "bleed" (Wither) and steals 10% of the damage as health
 * - right-click: throw the red ring (boomerang)
 * - sneak + right-click: spin attack around you
 */
public class CrimsonScytheItem extends SwordItem {
    public CrimsonScytheItem(Settings settings) {
        super(ScytheToolMaterial.INSTANCE, 3, -3.0F, settings);
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        target.setOnFireFor(8);
        // Bleeding: Wither II for 5 seconds
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 100, 1), attacker);
        // Life steal: a fraction of the weapon's damage comes back as health
        attacker.heal((float) (attacker.getAttributeValue(EntityAttributes.GENERIC_ATTACK_DAMAGE)
                * BossConfig.SCYTHE_LIFESTEAL));
        return super.postHit(stack, target, attacker);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient && world instanceof ServerWorld serverWorld) {
            if (user.isSneaking()) {
                spin(serverWorld, user);
            } else {
                ScytheRingEntity ring = new ScytheRingEntity(world, user);
                ring.setVelocity(user, user.getPitch(), user.getYaw(), 0.0F, 1.5F, 0.0F);
                world.spawnEntity(ring);
                world.playSound(null, user.getBlockPos(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP,
                        SoundCategory.PLAYERS, 1.0F, 0.6F);
            }
        }
        user.getItemCooldownManager().set(this, user.isSneaking() ? 40 : 30);
        return TypedActionResult.success(stack, world.isClient());
    }

    /** Hits everything around the player and steals health from the damage dealt. */
    private static void spin(ServerWorld world, PlayerEntity user) {
        double radius = BossConfig.SCYTHE_SPIN_RADIUS;
        float damage = (float) BossConfig.SCYTHE_SPIN_DAMAGE;
        int hits = 0;
        for (LivingEntity target : world.getEntitiesByClass(LivingEntity.class, user.getBoundingBox().expand(radius),
                e -> e != user && e.isAlive() && e.squaredDistanceTo(user) <= radius * radius)) {
            target.damage(world.getDamageSources().playerAttack(user), damage);
            target.setOnFireFor(4);
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 100, 1), user);
            Vec3d push = target.getPos().subtract(user.getPos()).normalize();
            target.addVelocity(push.x * 0.8, 0.3, push.z * 0.8);
            hits++;
        }
        user.heal((float) (damage * hits * BossConfig.SCYTHE_LIFESTEAL));
        world.spawnParticles(ParticleTypes.SWEEP_ATTACK, user.getX(), user.getY() + 1.0, user.getZ(), 12,
                radius / 2.0, 0.3, radius / 2.0, 0.0);
        world.playSound(null, user.getBlockPos(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, SoundCategory.PLAYERS, 1.5F, 0.5F);
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        tooltip.add(Text.literal("Hits steal 10% of the damage as health").formatted(Formatting.RED));
        tooltip.add(Text.literal("Right-click: throw the ring (returns)").formatted(Formatting.GRAY));
        tooltip.add(Text.literal("Sneak + right-click: spin attack").formatted(Formatting.GRAY));
    }
}
