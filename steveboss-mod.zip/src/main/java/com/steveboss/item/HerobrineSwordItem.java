package com.steveboss.item;

import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;

/** A very strong, fireproof sword with an enchantment glint. */
public class HerobrineSwordItem extends SwordItem {
    public HerobrineSwordItem(Settings settings) {
        super(HerobrineToolMaterial.INSTANCE, 3, -2.4F, settings);
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }
}
