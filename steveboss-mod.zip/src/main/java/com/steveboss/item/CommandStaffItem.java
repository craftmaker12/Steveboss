package com.steveboss.item;

import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.FireballEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.List;

/**
 * Command Block Staff.
 * Sneak + right-click: switch mode. Right-click: use the current mode.
 * Modes: 0 = Lightning (where you look), 1 = Fireball, 2 = Heal.
 */
public class CommandStaffItem extends Item {
    private static final String[] MODES = {"Lightning", "Fireball", "Heal"};
    private static final String MODE_KEY = "StaffMode";
    private static final int COOLDOWN_TICKS = 20;

    public CommandStaffItem(Settings settings) {
        super(settings);
    }

    private static int getMode(ItemStack stack) {
        NbtCompound nbt = stack.getNbt();
        int mode = nbt == null ? 0 : nbt.getInt(MODE_KEY);
        return Math.floorMod(mode, MODES.length);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        int mode = getMode(stack);

        // Sneak + right-click: next mode
        if (user.isSneaking()) {
            mode = (mode + 1) % MODES.length;
            stack.getOrCreateNbt().putInt(MODE_KEY, mode);
            if (!world.isClient) {
                user.sendMessage(Text.literal("Staff mode: " + MODES[mode]).formatted(Formatting.GOLD), true);
            }
            return TypedActionResult.success(stack, world.isClient());
        }

        if (!world.isClient) {
            switch (mode) {
                case 0 -> castLightning(world, user);
                case 1 -> castFireball(world, user);
                default -> castHeal(user);
            }
            world.playSound(null, user.getBlockPos(), SoundEvents.ENTITY_EVOKER_CAST_SPELL,
                    SoundCategory.PLAYERS, 1.0F, 1.0F);
        }
        user.getItemCooldownManager().set(this, COOLDOWN_TICKS);
        return TypedActionResult.success(stack, world.isClient());
    }

    private static void castLightning(World world, PlayerEntity user) {
        HitResult hit = user.raycast(100.0, 0.0F, false);
        LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(world);
        if (bolt != null) {
            bolt.refreshPositionAfterTeleport(hit.getPos());
            if (user instanceof ServerPlayerEntity serverPlayer) {
                bolt.setChanneler(serverPlayer);
            }
            world.spawnEntity(bolt);
        }
    }

    private static void castFireball(World world, PlayerEntity user) {
        Vec3d look = user.getRotationVec(1.0F);
        FireballEntity fireball = new FireballEntity(world, user, look.x, look.y, look.z, 3);
        fireball.setPosition(user.getX() + look.x * 1.5, user.getEyeY() + look.y * 1.5, user.getZ() + look.z * 1.5);
        world.spawnEntity(fireball);
    }

    private static void castHeal(PlayerEntity user) {
        user.heal(20.0F);
        user.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 20 * 30, 4));
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        tooltip.add(Text.literal("Mode: " + MODES[getMode(stack)]).formatted(Formatting.GOLD));
        tooltip.add(Text.literal("Right-click: use").formatted(Formatting.GRAY));
        tooltip.add(Text.literal("Sneak + right-click: change mode").formatted(Formatting.GRAY));
    }
}
