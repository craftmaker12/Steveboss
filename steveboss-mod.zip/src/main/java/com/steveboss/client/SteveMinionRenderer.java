package com.steveboss.client;

import com.steveboss.SteveBoss;
import com.steveboss.entity.SteveMinionEntity;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.util.Identifier;

public class SteveMinionRenderer extends BipedEntityRenderer<SteveMinionEntity, PlayerEntityModel<SteveMinionEntity>> {
    // Same skin as Steve, just smaller
    private static final Identifier TEXTURE = new Identifier(SteveBoss.MOD_ID, "textures/entity/steve.png");
    public static final float SCALE = 0.6F;

    public SteveMinionRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new PlayerEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER), false), 0.3F);
    }

    @Override
    protected void scale(SteveMinionEntity entity, net.minecraft.client.util.math.MatrixStack matrices, float amount) {
        matrices.scale(SCALE, SCALE, SCALE);
    }

    @Override
    public Identifier getTexture(SteveMinionEntity entity) {
        return TEXTURE;
    }
}
