package com.steveboss.client;

import com.steveboss.SteveBoss;
import com.steveboss.entity.SteveMinionEntity;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.util.Identifier;

public class SteveMinionRenderer extends BipedEntityRenderer<SteveMinionEntity, PlayerEntityModel<SteveMinionEntity>> {
    private static final Identifier TEXTURE = new Identifier(SteveBoss.MOD_ID, "textures/entity/steve_minion.png");

    public SteveMinionRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new PlayerEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER), false), 0.4F);
    }

    @Override
    public Identifier getTexture(SteveMinionEntity entity) {
        return TEXTURE;
    }
}
