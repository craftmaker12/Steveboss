package com.steveboss.client;

import com.steveboss.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.FlyingItemEntityRenderer;

public class SteveBossClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.STEVE_BOSS, SteveBossRenderer::new);
        EntityRendererRegistry.register(ModEntities.STEVE_MINION, SteveMinionRenderer::new);
        EntityRendererRegistry.register(ModEntities.SCYTHE_RING, ctx -> new FlyingItemEntityRenderer<>(ctx, 2.0F, true));
    }
}
