package com.steveboss.client;

import com.steveboss.SteveBoss;
import com.steveboss.entity.SteveBossEntity;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.util.Identifier;

/** Renders the boss with the player model; the skin depends on the current phase. */
public class SteveBossRenderer extends BipedEntityRenderer<SteveBossEntity, PlayerEntityModel<SteveBossEntity>> {
    private static final Identifier PHASE1 = new Identifier(SteveBoss.MOD_ID, "textures/entity/steve.png");
    private static final Identifier PHASE2 = new Identifier(SteveBoss.MOD_ID, "textures/entity/angry_steve.png");
    private static final Identifier PHASE3 = new Identifier(SteveBoss.MOD_ID, "textures/entity/herobrine.png");

    public SteveBossRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new PlayerEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER), false), 0.5F);
    }

    @Override
    public Identifier getTexture(SteveBossEntity entity) {
        return switch (entity.getPhase()) {
            case 1 -> PHASE1;
            case 2 -> PHASE2;
            default -> PHASE3;
        };
    }
}
