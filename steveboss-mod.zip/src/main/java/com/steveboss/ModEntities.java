package com.steveboss;

import com.steveboss.entity.SteveBossEntity;
import com.steveboss.entity.SteveMinionEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModEntities {
    private ModEntities() {
    }

    public static final EntityType<SteveBossEntity> STEVE_BOSS = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(SteveBoss.MOD_ID, "steve_boss"),
            FabricEntityTypeBuilder.<SteveBossEntity>create(SpawnGroup.MONSTER, SteveBossEntity::new)
                    .dimensions(EntityDimensions.fixed(0.6F, 1.95F))
                    .trackRangeBlocks(96)
                    .fireImmune()
                    .build()
    );

    public static final EntityType<SteveMinionEntity> STEVE_MINION = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(SteveBoss.MOD_ID, "steve_minion"),
            FabricEntityTypeBuilder.<SteveMinionEntity>create(SpawnGroup.MONSTER, SteveMinionEntity::new)
                    .dimensions(EntityDimensions.fixed(0.6F, 1.95F))
                    .trackRangeBlocks(64)
                    .build()
    );

    public static void register() {
        FabricDefaultAttributeRegistry.register(STEVE_BOSS, SteveBossEntity.createBossAttributes());
        FabricDefaultAttributeRegistry.register(STEVE_MINION, SteveMinionEntity.createMinionAttributes());
    }
}
