package com.steveboss.util;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.ItemStack;

public final class MobUtil {
    private MobUtil() {
    }

    /** Sets the base attack damage directly (use for mobs without a weapon). */
    public static void setBaseAttackDamage(LivingEntity entity, double value) {
        EntityAttributeInstance attr = entity.getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE);
        if (attr != null) {
            attr.setBaseValue(value);
        }
    }

    /**
     * Makes the entity deal exactly {@code totalDamage} while holding {@code mainHand}.
     * The weapon's own attack-damage bonus is subtracted from the base value,
     * so the final damage (base + weapon) equals the requested number.
     */
    public static void setExactAttackDamage(LivingEntity entity, ItemStack mainHand, double totalDamage) {
        double weaponBonus = 0.0;
        for (EntityAttributeModifier modifier : mainHand
                .getAttributeModifiers(EquipmentSlot.MAINHAND)
                .get(EntityAttributes.GENERIC_ATTACK_DAMAGE)) {
            if (modifier.getOperation() == EntityAttributeModifier.Operation.ADDITION) {
                weaponBonus += modifier.getValue();
            }
        }
        setBaseAttackDamage(entity, Math.max(0.0, totalDamage - weaponBonus));
    }
}
