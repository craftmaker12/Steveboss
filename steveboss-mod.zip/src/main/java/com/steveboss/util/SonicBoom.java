package com.steveboss.util;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.function.Predicate;

/** The Warden's "sonic boom": a beam of particles that damages everything along a line. */
public final class SonicBoom {
    private SonicBoom() {
    }

    public static void fire(ServerWorld world, LivingEntity shooter, Vec3d from, Vec3d direction, double range,
                            float damage, SoundCategory sound, Predicate<LivingEntity> canHit) {
        Vec3d dir = direction.normalize();

        for (int i = 1; i <= (int) range; i++) {
            Vec3d p = from.add(dir.multiply(i));
            world.spawnParticles(ParticleTypes.SONIC_BOOM, p.x, p.y, p.z, 1, 0.0, 0.0, 0.0, 0.0);
        }
        world.playSound(null, shooter.getBlockPos(), SoundEvents.ENTITY_WARDEN_SONIC_BOOM, sound, 3.0F, 1.0F);

        Box area = new Box(from, from.add(dir.multiply(range))).expand(2.0);
        for (LivingEntity target : world.getEntitiesByClass(LivingEntity.class, area,
                e -> e != shooter && e.isAlive() && canHit.test(e))) {
            Vec3d center = target.getBoundingBox().getCenter();
            double along = MathHelper.clamp(center.subtract(from).dotProduct(dir), 0.0, range);
            Vec3d closest = from.add(dir.multiply(along));
            if (center.distanceTo(closest) > 1.5 + target.getWidth() / 2.0) {
                continue;
            }
            target.damage(world.getDamageSources().sonicBoom(shooter), damage);
            double resist = 1.0 - target.getAttributeValue(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE);
            target.addVelocity(dir.x * 2.5 * resist, dir.y * 0.5 * resist, dir.z * 2.5 * resist);
        }
    }
}
