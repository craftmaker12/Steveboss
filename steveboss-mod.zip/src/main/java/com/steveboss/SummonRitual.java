package com.steveboss;

import com.steveboss.entity.SteveBossEntity;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Summoning ritual:
 * <ul>
 *   <li>3x3 platform of Blue Concrete</li>
 *   <li>1 Cyan Concrete block on the middle of the platform</li>
 *   <li>at least 3 Torches standing on the platform around the Cyan block</li>
 *   <li>light the top of the Cyan block with Flint and Steel</li>
 * </ul>
 */
public final class SummonRitual {
    private SummonRitual() {
    }

    public static void register() {
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (player.isSpectator() || hit.getSide() != Direction.UP) {
                return ActionResult.PASS;
            }
            ItemStack stack = player.getStackInHand(hand);
            if (!stack.isOf(Items.FLINT_AND_STEEL)) {
                return ActionResult.PASS;
            }
            BlockPos pos = hit.getBlockPos();
            if (!isRitualBuilt(world, pos)) {
                return ActionResult.PASS;
            }
            if (world instanceof ServerWorld serverWorld) {
                summon(serverWorld, pos, player, stack, hand);
            }
            return ActionResult.SUCCESS;
        });
    }

    /** @param pos the Cyan Concrete block that was clicked */
    private static boolean isRitualBuilt(World world, BlockPos pos) {
        if (!world.getBlockState(pos).isOf(Blocks.CYAN_CONCRETE) || !world.getBlockState(pos.up()).isAir()) {
            return false;
        }
        BlockPos floor = pos.down();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (!world.getBlockState(floor.add(dx, 0, dz)).isOf(Blocks.BLUE_CONCRETE)) {
                    return false;
                }
            }
        }
        return countTorches(world, pos) >= 3;
    }

    private static int countTorches(World world, BlockPos pos) {
        int torches = 0;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if ((dx != 0 || dz != 0) && world.getBlockState(pos.add(dx, 0, dz)).isOf(Blocks.TORCH)) {
                    torches++;
                }
            }
        }
        return torches;
    }

    private static void summon(ServerWorld world, BlockPos pos, PlayerEntity player, ItemStack stack, Hand hand) {
        // Consume the ritual pieces
        world.setBlockState(pos, Blocks.AIR.getDefaultState());
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                BlockPos p = pos.add(dx, 0, dz);
                if (world.getBlockState(p).isOf(Blocks.TORCH)) {
                    world.setBlockState(p, Blocks.AIR.getDefaultState());
                }
            }
        }
        stack.damage(1, player, p -> p.sendToolBreakStatus(hand));

        // Effects (the bolt is cosmetic: no fire, no damage)
        LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(world);
        if (bolt != null) {
            bolt.refreshPositionAfterTeleport(Vec3d.ofBottomCenter(pos));
            bolt.setCosmetic(true);
            world.spawnEntity(bolt);
        }
        world.playSound(null, pos, SoundEvents.ENTITY_WITHER_SPAWN, SoundCategory.HOSTILE, 1.5F, 1.0F);

        // The boss
        SteveBossEntity boss = ModEntities.STEVE_BOSS.create(world);
        if (boss != null) {
            boss.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, player.getYaw() + 180.0F, 0.0F);
            boss.setTarget(player);
            world.spawnEntity(boss);
        }
    }
}
