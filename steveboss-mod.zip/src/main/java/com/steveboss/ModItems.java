package com.steveboss;

import com.steveboss.item.HerobrineSwordItem;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;

public final class ModItems {
    private ModItems() {
    }

    public static final Item STEVE_BOSS_SPAWN_EGG = Registry.register(
            Registries.ITEM,
            new Identifier(SteveBoss.MOD_ID, "steve_boss_spawn_egg"),
            new SpawnEggItem(ModEntities.STEVE_BOSS, 0x00AAAA, 0x4A3621, new Item.Settings())
    );

    public static final Item HEROBRINE_SWORD = Registry.register(
            Registries.ITEM,
            new Identifier(SteveBoss.MOD_ID, "herobrine_sword"),
            new HerobrineSwordItem(new Item.Settings().rarity(Rarity.EPIC).fireproof())
    );

    public static final Item COMMAND_STAFF = Registry.register(
            Registries.ITEM,
            new Identifier(SteveBoss.MOD_ID, "command_staff"),
            new com.steveboss.item.CommandStaffItem(new Item.Settings().maxCount(1).rarity(Rarity.EPIC).fireproof())
    );

    /** Only used to draw the flying ring; not shown in the Creative tabs. */
    public static final Item SCYTHE_RING = Registry.register(
            Registries.ITEM,
            new Identifier(SteveBoss.MOD_ID, "scythe_ring"),
            new Item(new Item.Settings())
    );

    public static final Item CRIMSON_SCYTHE = Registry.register(
            Registries.ITEM,
            new Identifier(SteveBoss.MOD_ID, "crimson_scythe"),
            new com.steveboss.item.CrimsonScytheItem(new Item.Settings().rarity(Rarity.EPIC).fireproof())
    );

    /** 99999 durability, fireproof (survives lava like Netherite). */
    public static final Item CRYSTAL_BOW = Registry.register(
            Registries.ITEM,
            new Identifier(SteveBoss.MOD_ID, "crystal_bow"),
            new net.minecraft.item.BowItem(new Item.Settings().maxDamage(99999).rarity(Rarity.EPIC).fireproof())
    );

    /**
     * Arrow damage = ceil(speed * damage). A full draw has speed 3, so the base damage of 2
     * plus this bonus (13) gives (2 + 13) * 3 = 45.
     */
    private static final double CRYSTAL_BOW_BONUS = 13.0;
    private static final String BOOSTED_TAG = "steveboss_boosted";

    public static void register() {
        // Arrows fired by someone holding the Crystal Bow hit for 45 (at full draw)
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity instanceof net.minecraft.entity.projectile.PersistentProjectileEntity arrow
                    && !(arrow instanceof net.minecraft.entity.projectile.TridentEntity)
                    && arrow.getOwner() instanceof net.minecraft.entity.LivingEntity owner
                    && !arrow.getCommandTags().contains(BOOSTED_TAG)
                    && (owner.getMainHandStack().isOf(CRYSTAL_BOW) || owner.getOffHandStack().isOf(CRYSTAL_BOW))) {
                arrow.addCommandTag(BOOSTED_TAG);
                arrow.setDamage(arrow.getDamage() + CRYSTAL_BOW_BONUS);
                // A full-draw shot (critical arrow) also fires a sonic boom along the aim direction
                if (arrow.isCritical()) {
                    com.steveboss.util.SonicBoom.fire(world, owner, owner.getEyePos(), owner.getRotationVec(1.0F),
                            BossConfig.BOW_SONIC_BOOM_RANGE, (float) BossConfig.BOW_SONIC_BOOM_DAMAGE,
                            net.minecraft.sound.SoundCategory.PLAYERS, e -> true);
                }
            }
        });

        // Our own Creative tab with everything from the mod
        net.minecraft.item.ItemGroup tab = net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup.builder()
                .icon(() -> new net.minecraft.item.ItemStack(HEROBRINE_SWORD))
                .displayName(net.minecraft.text.Text.translatable("itemGroup.steveboss.main"))
                .entries((context, entries) -> {
                    entries.add(STEVE_BOSS_SPAWN_EGG);
                    entries.add(HEROBRINE_SWORD);
                    entries.add(COMMAND_STAFF);
                    entries.add(CRYSTAL_BOW);
                    entries.add(CRIMSON_SCYTHE);
                })
                .build();
        Registry.register(Registries.ITEM_GROUP, new Identifier(SteveBoss.MOD_ID, "main"), tab);

        // Show the egg in the Creative "Spawn Eggs" tab
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS)
                .register(entries -> entries.add(STEVE_BOSS_SPAWN_EGG));
        // Show the sword in the Creative "Combat" tab
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT)
                .register(entries -> {
                    entries.add(HEROBRINE_SWORD);
                    entries.add(COMMAND_STAFF);
                    entries.add(CRYSTAL_BOW);
                    entries.add(CRIMSON_SCYTHE);
                });
    }
}
