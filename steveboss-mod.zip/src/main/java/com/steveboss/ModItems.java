package com.steveboss;

import com.steveboss.item.HerobrineSwordItem;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;

public final class ModItems {
    private ModItems() {
    }

    public static final Item STEVE_BOSS_SPAWN_EGG = Registry.register(
            Registries.ITEM,
            new Identifier(SteveBoss.MOD_ID, "steve_boss_spawn_egg"),
            new SpawnEggItem(ModEntities.STEVE_BOSS, 0x00AAAA, 0x4A3621, new Item.Settings())
    );

    public static final Item HEROBRINE_SWORD = Registry.register(
            Registries.ITEM,
            new Identifier(SteveBoss.MOD_ID, "herobrine_sword"),
            new HerobrineSwordItem(new Item.Settings().rarity(Rarity.EPIC).fireproof())
    );

    public static void register() {
        // Show the egg in the Creative "Spawn Eggs" tab
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS)
                .register(entries -> entries.add(STEVE_BOSS_SPAWN_EGG));
        // Show the sword in the Creative "Combat" tab
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT)
                .register(entries -> entries.add(HEROBRINE_SWORD));
    }
}
