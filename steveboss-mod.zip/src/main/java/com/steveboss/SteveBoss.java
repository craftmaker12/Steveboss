package com.steveboss;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SteveBoss implements ModInitializer {
    public static final String MOD_ID = "steveboss";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModEntities.register();
        ModItems.register();
        SummonRitual.register();
        LOGGER.info("Steve Boss loaded. Use the summoning ritual, the spawn egg in Creative, or /summon steveboss:steve_boss.");
    }
}
