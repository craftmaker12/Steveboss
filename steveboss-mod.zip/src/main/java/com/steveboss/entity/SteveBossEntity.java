package com.steveboss.entity;

import com.steveboss.BossConfig;
import com.steveboss.ModEntities;
import com.steveboss.ModItems;
import com.steveboss.util.MobUtil;
import com.steveboss.util.SonicBoom;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.TntEntity;
import net.minecraft.world.GameRules;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.SmallFireballEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;

/**
 * Three-phase boss: Steve -> Error 404 -> HEROBRINE.
 * One entity that "transforms" instead of dying between phases.
 */
public class SteveBossEntity extends HostileEntity {
    private static final TrackedData<Integer> PHASE =
            DataTracker.registerData(SteveBossEntity.class, TrackedDataHandlerRegistry.INTEGER);

    private final ServerBossBar bossBar =
            new ServerBossBar(Text.literal("Steve"), BossBar.Color.GREEN, BossBar.Style.PROGRESS);

    /** Real HP of the phase divided by the (capped) attribute HP. 1.0 unless the phase exceeds 1024 HP. */
    private double damageScale = 1.0;
    private boolean introDone = false;
    private int transitionTicks = 0;
    private int minionTimer = 0;
    private int lightningTimer = 0;
    private int diamondTimer = 0;
    private int teleportTimer = 0;
    private int fireballTimer = 0;
    private int sonicTimer = 0;
    private int tntTimer = 0;
    private final List<PendingTnt> pendingTnts = new ArrayList<>();
    private boolean enraged = false;

    public SteveBossEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 500;
        this.setPersistent();
    }

    public static DefaultAttributeContainer.Builder createBossAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, BossConfig.PHASE1_HEALTH)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, BossConfig.PHASE1_DAMAGE)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.32)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.8);
    }

    // ------------------------------------------------------------------ setup

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new SwimGoal(this));
        this.goalSelector.add(2, new MeleeAttackGoal(this, 1.1, false));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.8));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 12.0F));
        this.goalSelector.add(7, new LookAroundGoal(this));
        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    protected void initDataTracker() {
        super.initDataTracker();
        this.dataTracker.startTracking(PHASE, 1);
    }

    public int getPhase() {
        return this.dataTracker.get(PHASE);
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }

    // ------------------------------------------------------------------ phases

    private static String phaseName(int phase) {
        return switch (phase) {
            case 1 -> "Steve";
            case 2 -> "Error 404";
            default -> "HEROBRINE";
        };
    }

    /**
     * Applies health / damage / equipment / name of a phase.
     *
     * @param heal true on a real transition (refill HP), false when loading from disk
     */
    private void applyPhase(int phase, boolean heal) {
        double realHealth;
        double damage;
        Formatting color;
        BossBar.Color barColor;
        switch (phase) {
            case 1 -> {
                realHealth = BossConfig.PHASE1_HEALTH;
                damage = BossConfig.PHASE1_DAMAGE;
                color = Formatting.GREEN;
                barColor = BossBar.Color.GREEN;
            }
            case 2 -> {
                realHealth = BossConfig.PHASE2_HEALTH;
                damage = BossConfig.PHASE2_DAMAGE;
                color = Formatting.LIGHT_PURPLE;
                barColor = BossBar.Color.PURPLE;
            }
            default -> {
                realHealth = BossConfig.PHASE3_HEALTH;
                damage = BossConfig.PHASE3_DAMAGE;
                color = Formatting.DARK_RED;
                barColor = BossBar.Color.RED;
            }
        }

        // Vanilla clamps max health to 1024, so anything above is emulated by scaling incoming damage.
        double attributeHealth = Math.min(realHealth, BossConfig.VANILLA_MAX_HEALTH_CAP);
        this.damageScale = attributeHealth / realHealth;
        EntityAttributeInstance maxHealth = this.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        if (maxHealth != null) {
            maxHealth.setBaseValue(attributeHealth);
        }
        if (heal) {
            this.setHealth((float) attributeHealth);
        }

        if (phase >= 3) {
            ItemStack sword = new ItemStack(Items.NETHERITE_SWORD);
            this.equipStack(EquipmentSlot.MAINHAND, sword);
            MobUtil.setExactAttackDamage(this, sword, this.enraged ? BossConfig.RAGE_ATTACK_DAMAGE : damage);
        } else {
            this.equipStack(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            MobUtil.setBaseAttackDamage(this, damage);
        }
        this.setEquipmentDropChance(EquipmentSlot.MAINHAND, 0.0F);

        Text name = Text.literal(phaseName(phase)).formatted(color, Formatting.BOLD);
        this.setCustomName(name);
        this.setCustomNameVisible(true);
        this.bossBar.setName(name);
        this.bossBar.setColor(barColor);
    }

    private void advancePhase() {
        int next = this.getPhase() + 1;
        this.dataTracker.set(PHASE, next);
        this.applyPhase(next, true);
        this.transitionTicks = 40; // 2 seconds of invulnerability
        this.minionTimer = 0;
        this.lightningTimer = 60;
        this.diamondTimer = 100;
        this.teleportTimer = 100;
        this.fireballTimer = 80;
        this.sonicTimer = 60;
        this.tntTimer = 150;
        this.setTarget(this.getTarget());

        if (this.getWorld() instanceof ServerWorld world) {
            world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, this.getX(), this.getY() + 1.0, this.getZ(),
                    1, 0.0, 0.0, 0.0, 0.0);
            world.playSound(null, this.getBlockPos(), SoundEvents.ENTITY_WITHER_SPAWN, SoundCategory.HOSTILE,
                    2.0F, next == 3 ? 0.5F : 1.0F);

            if (next == 2) {
                this.spawnMinion(world, false); // Steve Minion with Stone Sword
                this.giveBuff(world);
            } else if (next == 3) {
                this.keepThunderstorm(world, true);
                world.playSound(null, this.getBlockPos(), SoundEvents.ENTITY_ENDER_DRAGON_GROWL,
                        SoundCategory.HOSTILE, 3.0F, 0.6F);
                this.broadcast(Text.literal("Steve has turned into HEROBRINE!").formatted(Formatting.DARK_RED, Formatting.BOLD));
            }
        }
    }

    /** "Get ready": Health Boost + Resistance + Strength for the players near the boss. */
    private void giveBuff(ServerWorld world) {
        double radius = BossConfig.PHASE2_BUFF_RADIUS;
        for (ServerPlayerEntity player : world.getPlayers(
                p -> p.isAlive() && !p.isSpectator() && p.squaredDistanceTo(this) <= radius * radius)) {
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.HEALTH_BOOST,
                    BossConfig.PHASE2_HEALTH_BOOST_SECONDS * 20, BossConfig.PHASE2_HEALTH_BOOST_AMPLIFIER,
                    false, false, true));
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE,
                    BossConfig.PHASE2_RESISTANCE_SECONDS * 20, BossConfig.PHASE2_RESISTANCE_AMPLIFIER,
                    false, false, true));
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH,
                    BossConfig.PHASE2_STRENGTH_SECONDS * 20, BossConfig.PHASE2_STRENGTH_AMPLIFIER,
                    false, false, true));
            player.setHealth(player.getMaxHealth());
            player.getInventory().offerOrDrop(new ItemStack(ModItems.SHOTGUN));
            int ammo = BossConfig.SHOTGUN_AMMO_GIVEN;
            while (ammo > 0) {
                int n = Math.min(ammo, ModItems.SHOTGUN_AMMO.getMaxCount());
                player.getInventory().offerOrDrop(new ItemStack(ModItems.SHOTGUN_AMMO, n));
                ammo -= n;
            }
            player.sendMessage(Text.literal("Get ready! Health Boost + Resistance + Strength + Shotgun")
                    .formatted(Formatting.GOLD, Formatting.BOLD), true);
        }
    }

    // ------------------------------------------------------------------ damage / death

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (this.getWorld().isClient) {
            return super.damage(source, amount);
        }
        // /kill, void, etc. go straight through.
        if (source.isIn(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return super.damage(source, amount);
        }
        if (this.transitionTicks > 0) {
            return false;
        }

        float scaled = (float) (amount * this.damageScale);
        if (this.getPhase() < 3 && scaled >= this.getHealth()) {
            // Would die -> transform into the next phase instead.
            this.advancePhase();
            return true;
        }
        return super.damage(source, scaled);
    }

    @Override
    public void onStruckByLightning(ServerWorld world, LightningEntity lightning) {
        // Herobrine is immune to his own lightning.
    }

    @Override
    public void onDeath(DamageSource source) {
        super.onDeath(source);
        if (!(this.getWorld() instanceof ServerWorld world)) {
            return;
        }
        this.bossBar.clearPlayers();

        // Cancel TNTs still waiting to explode
        for (PendingTnt pending : this.pendingTnts) {
            pending.tnt.discard();
        }
        this.pendingTnts.clear();

        // Remove leftover minions
        for (SteveMinionEntity minion : this.nearbyMinions(world, 80.0)) {
            minion.kill();
        }

        PlayerEntity killer = null;
        Entity attacker = source.getAttacker();
        if (attacker instanceof PlayerEntity player) {
            killer = player;
        } else if (this.getAttacker() instanceof PlayerEntity lastPlayer) {
            killer = lastPlayer;
        }

        Text title = Text.literal(phaseName(this.getPhase())).formatted(Formatting.DARK_RED, Formatting.BOLD);
        if (killer != null) {
            this.broadcast(Text.empty()
                    .append(title)
                    .append(Text.literal(" was defeated by ").formatted(Formatting.GRAY))
                    .append(killer.getDisplayName().copy().formatted(Formatting.GOLD, Formatting.BOLD))
                    .append(Text.literal("!").formatted(Formatting.GRAY)));
        } else {
            this.broadcast(Text.empty()
                    .append(title)
                    .append(Text.literal(" has been defeated!").formatted(Formatting.GRAY)));
        }

        if (this.getPhase() >= 3) {
            world.setWeather(6000, 0, false, false); // stop the storm
            this.giveRewards(killer);
        }
    }

    /** Gives the loot to the killer; whatever does not fit in the inventory drops at their feet. */
    private void giveRewards(PlayerEntity killer) {
        List<ItemStack> rewards = new ArrayList<>();
        rewards.add(new ItemStack(Items.ELYTRA));
        addSplit(rewards, Items.FIREWORK_ROCKET, BossConfig.REWARD_FIREWORKS, true);
        addSplit(rewards, Items.DIAMOND_BLOCK, BossConfig.REWARD_DIAMOND_BLOCKS, false);
        addSplit(rewards, Items.DRAGON_EGG, BossConfig.REWARD_DRAGON_EGGS, false);
        addSplit(rewards, Items.NETHERITE_BLOCK, BossConfig.REWARD_NETHERITE_BLOCKS, false);
        rewards.add(this.skeletonSpawner());
        rewards.add(new ItemStack(ModItems.COMMAND_STAFF));
        rewards.add(new ItemStack(ModItems.CRIMSON_SCYTHE));
        for (ItemStack reward : rewards) {
            if (killer != null) {
                killer.getInventory().offerOrDrop(reward);
            } else {
                this.dropStack(reward);
            }
        }
        if (killer != null) {
            killer.sendMessage(Text.literal("Reward: Elytra, "
                    + BossConfig.REWARD_FIREWORKS + " Fireworks, "
                    + BossConfig.REWARD_DIAMOND_BLOCKS + " Diamond Blocks, "
                    + BossConfig.REWARD_DRAGON_EGGS + " Dragon Eggs, "
                    + BossConfig.REWARD_NETHERITE_BLOCKS + " Netherite Blocks, Skeleton Spawner, Command Staff, Crimson Scythe")
                    .formatted(Formatting.GOLD, Formatting.BOLD), false);
        }
    }

    /** Splits a big count into normal stacks (a stack above its max size would break). */
    private static void addSplit(List<ItemStack> out, net.minecraft.item.Item item, int total, boolean flightTag) {
        int left = total;
        while (left > 0) {
            ItemStack stack = new ItemStack(item, Math.min(left, item.getMaxCount()));
            if (flightTag) {
                stack.getOrCreateSubNbt("Fireworks").putByte("Flight", (byte) BossConfig.REWARD_FIREWORK_FLIGHT);
            }
            out.add(stack);
            left -= stack.getCount();
        }
    }

    /** A Monster Spawner item that spawns Skeletons when placed. */
    private ItemStack skeletonSpawner() {
        ItemStack spawner = new ItemStack(Items.SPAWNER);
        NbtCompound entity = new NbtCompound();
        entity.putString("id", "minecraft:skeleton");
        NbtCompound spawnData = new NbtCompound();
        spawnData.put("entity", entity);
        spawner.getOrCreateSubNbt("BlockEntityTag").put("SpawnData", spawnData);
        return spawner;
    }

    @Override
    public void remove(RemovalReason reason) {
        if (!this.getWorld().isClient) {
            this.bossBar.clearPlayers();
            if (this.getPhase() >= 3 && this.getWorld() instanceof ServerWorld world
                    && (reason == RemovalReason.KILLED || reason == RemovalReason.DISCARDED)) {
                world.setWeather(6000, 0, false, false);
            }
        }
        super.remove(reason);
    }

    // ------------------------------------------------------------------ tick

    @Override
    protected void mobTick() {
        super.mobTick();
        if (!(this.getWorld() instanceof ServerWorld world)) {
            return;
        }
        this.bossBar.setPercent(this.getHealth() / this.getMaxHealth());

        if (this.transitionTicks > 0) {
            this.transitionTicks--;
        }

        int phase = this.getPhase();

        if (!this.introDone) {
            this.introDone = true;
            if (phase == 1) {
                this.summonPhaseOneHelpers(world);
            }
        }

        if (phase == 2) {
            if (++this.minionTimer >= 500 && this.nearbyMinions(world, 40.0).size() < BossConfig.MAX_MINIONS_ALIVE) {
                this.minionTimer = 0;
                this.spawnMinion(world, false);
            }
        }

        if (phase >= 3) {
            // Pending TNT: replace the vanilla explosion by the huge one
            this.pendingTnts.removeIf(pending -> {
                if (pending.tnt.isRemoved()) {
                    return true;
                }
                if (--pending.ticks > 0) {
                    return false;
                }
                Vec3d at = pending.tnt.getPos();
                pending.tnt.discard();
                this.hugeExplosion(world, at);
                return true;
            });

            // Rage mode: below 50% health
            if (!this.enraged && this.getHealth() <= this.getMaxHealth() * BossConfig.RAGE_HEALTH_FRACTION) {
                this.startRage(world);
            }
            if (this.enraged && this.age % 4 == 0) {
                world.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, this.getX(), this.getY() + 1.0, this.getZ(),
                        6, 0.4, 0.8, 0.4, 0.02);
            }

            if (this.age % 100 == 0) {
                this.keepThunderstorm(world, false);
            }

            LivingEntity target = this.getTarget();
            if (this.enraged && target != null && target.isAlive()) {
                this.flyTowards(target);
            }
            if (target instanceof PlayerEntity player && player.isAlive() && !player.isSpectator()) {
                // Ability 1: lightning bolt on the player
                if ((this.lightningTimer += this.step()) >= BossConfig.LIGHTNING_INTERVAL_TICKS) {
                    this.lightningTimer = 0;
                    LightningEntity bolt = net.minecraft.entity.EntityType.LIGHTNING_BOLT.create(world);
                    if (bolt != null) {
                        bolt.refreshPositionAfterTeleport(player.getPos());
                        world.spawnEntity(bolt);
                    }
                }
                // Ability 6: drop a TNT on the player
                if (this.pendingTnts.isEmpty() && (this.tntTimer += this.step()) >= BossConfig.TNT_INTERVAL_TICKS) {
                    this.tntTimer = 0;
                    this.dropTnt(world, player);
                }
                // Ability 5: sonic boom (needs line of sight)
                if ((this.sonicTimer += this.step()) >= BossConfig.SONIC_BOOM_INTERVAL_TICKS && this.canSee(player)
                        && this.squaredDistanceTo(player) <= BossConfig.SONIC_BOOM_RANGE * BossConfig.SONIC_BOOM_RANGE) {
                    this.sonicTimer = 0;
                    Vec3d from = this.getEyePos();
                    Vec3d aim = player.getEyePos().subtract(from);
                    int beams = this.enraged ? BossConfig.RAGE_SONIC_BEAMS : 1;
                    for (int b = 0; b < beams; b++) {
                        // several beams fan out around the aim direction
                        double angle = beams == 1 ? 0.0 : (b - (beams - 1) / 2.0) * 0.35;
                        SonicBoom.fire(world, this, from, aim.rotateY((float) angle), BossConfig.SONIC_BOOM_RANGE,
                                (float) (this.enraged ? BossConfig.RAGE_SONIC_BOOM_DAMAGE : BossConfig.SONIC_BOOM_DAMAGE),
                                SoundCategory.HOSTILE,
                                target2 -> !(target2 instanceof SteveMinionEntity));
                    }
                }
                // Ability 4: fireballs dropped from above onto the player
                if ((this.fireballTimer += this.step()) >= BossConfig.FIREBALL_INTERVAL_TICKS) {
                    this.fireballTimer = 0;
                    this.dropFireballs(world, player);
                }
                // Ability 3: teleport next to the player
                if ((this.teleportTimer += this.step()) >= BossConfig.TELEPORT_INTERVAL_TICKS) {
                    this.teleportTimer = 0;
                    this.teleportNear(world, player);
                }
                // Ability 2: Steve Minion with Diamond Sword
                if ((this.diamondTimer += this.step()) >= BossConfig.DIAMOND_MINION_INTERVAL_TICKS) {
                    this.diamondTimer = 0;
                    if (this.nearbyMinions(world, 40.0).size() < BossConfig.MAX_MINIONS_ALIVE) {
                        this.spawnMinion(world, true);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ helpers

    private static final class PendingTnt {
        final TntEntity tnt;
        int ticks;

        PendingTnt(TntEntity tnt, int ticks) {
            this.tnt = tnt;
            this.ticks = ticks;
        }
    }

    /** Rage mode makes every ability recharge faster. */
    private int step() {
        return this.enraged ? BossConfig.RAGE_ABILITY_SPEEDUP : 1;
    }

    private void startRage(ServerWorld world) {
        this.enraged = true;
        this.setNoGravity(true);
        MobUtil.setExactAttackDamage(this, this.getEquippedStack(EquipmentSlot.MAINHAND), BossConfig.RAGE_ATTACK_DAMAGE);
        EntityAttributeInstance speed = this.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        if (speed != null) {
            speed.setBaseValue(BossConfig.RAGE_MOVEMENT_SPEED);
        }
        world.playSound(null, this.getBlockPos(), SoundEvents.ENTITY_ENDER_DRAGON_GROWL, SoundCategory.HOSTILE, 4.0F, 0.5F);
        this.broadcast(Text.literal("HEROBRINE is enraged!").formatted(Formatting.DARK_RED, Formatting.BOLD));

        // Help for the nearest player: Herobrine Sword + Crystal Bow (straight into the inventory, never on the ground)
        PlayerEntity nearest = world.getClosestPlayer(this, 128.0);
        if (nearest != null && !nearest.isSpectator()) {
            nearest.getInventory().offerOrDrop(new ItemStack(ModItems.HEROBRINE_SWORD));
            nearest.getInventory().offerOrDrop(new ItemStack(ModItems.CRYSTAL_BOW));
            nearest.sendMessage(Text.literal("Herobrine dropped his Sword and Crystal Bow for you!")
                    .formatted(Formatting.GOLD, Formatting.BOLD), true);
        }
    }

    /** Rage mode: fly straight at the target at a fantasy speed. */
    private void flyTowards(LivingEntity target) {
        Vec3d goal = target.getPos().add(0.0, 1.0, 0.0);
        Vec3d delta = goal.subtract(this.getPos());
        double dist = delta.length();
        if (dist > 2.0) {
            double speed = Math.min(BossConfig.RAGE_FLY_SPEED, dist * 0.35);
            this.setVelocity(delta.normalize().multiply(speed));
        } else {
            this.setVelocity(this.getVelocity().multiply(0.5));
        }
    }

    private void dropTnt(ServerWorld world, PlayerEntity target) {
        int count = this.enraged ? BossConfig.RAGE_TNT_COUNT : 1;
        for (int i = 0; i < count; i++) {
            double ox = i == 0 ? 0.0 : (this.random.nextDouble() - 0.5) * 12.0;
            double oz = i == 0 ? 0.0 : (this.random.nextDouble() - 0.5) * 12.0;
            int fuse = BossConfig.TNT_FUSE_TICKS + i * 20; // staggered: one explosion per second
            TntEntity tnt = new TntEntity(world, target.getX() + ox, target.getY() + 4.0, target.getZ() + oz, this);
            tnt.setFuse(fuse);
            world.spawnEntity(tnt);
            // we blow it up ourselves just before vanilla does
            this.pendingTnts.add(new PendingTnt(tnt, fuse - 2));
        }
        world.playSound(null, target.getBlockPos(), SoundEvents.ENTITY_TNT_PRIMED, SoundCategory.HOSTILE, 2.0F, 1.0F);
    }

    /** Huge explosion: everything within the radius takes damage, plus a crater around the center. */
    private void hugeExplosion(ServerWorld world, Vec3d at) {
        for (int i = 0; i < 8; i++) {
            world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER,
                    at.x + (this.random.nextDouble() - 0.5) * 8.0, at.y + this.random.nextDouble() * 3.0,
                    at.z + (this.random.nextDouble() - 0.5) * 8.0, 1, 0.0, 0.0, 0.0, 0.0);
        }
        world.playSound(null, BlockPos.ofFloored(at), SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.HOSTILE, 10.0F, 0.6F);

        double radius = BossConfig.TNT_EXPLOSION_RADIUS;
        Box area = new Box(at.x - radius, at.y - radius, at.z - radius, at.x + radius, at.y + radius, at.z + radius);
        for (LivingEntity victim : world.getEntitiesByClass(LivingEntity.class, area,
                e -> e.isAlive() && e != this && !(e instanceof SteveMinionEntity)
                        && e.squaredDistanceTo(at) <= radius * radius)) {
            victim.damage(world.getDamageSources().explosion(this, this), (float) (this.enraged ? BossConfig.RAGE_TNT_DAMAGE : BossConfig.TNT_DAMAGE));
        }

        int r = BossConfig.TNT_BLOCK_RADIUS;
        if (r > 0 && world.getGameRules().getBoolean(GameRules.DO_MOB_GRIEFING)) {
            BlockPos center = BlockPos.ofFloored(at);
            for (int dx = -r; dx <= r; dx++) {
                for (int dy = -r; dy <= r; dy++) {
                    for (int dz = -r; dz <= r; dz++) {
                        if (dx * dx + dy * dy + dz * dz > r * r) {
                            continue;
                        }
                        BlockPos pos = center.add(dx, dy, dz);
                        var state = world.getBlockState(pos);
                        if (!state.isAir() && state.getHardness(world, pos) >= 0.0F) {
                            world.breakBlock(pos, false);
                        }
                    }
                }
            }
        }
    }

    /** Rains a few fireballs on the player; each hit deals {@link BossConfig#FIREBALL_DAMAGE}. */
    private void dropFireballs(ServerWorld world, PlayerEntity target) {
        int count = BossConfig.FIREBALL_COUNT * (this.enraged ? BossConfig.RAGE_FIREBALL_MULTIPLIER : 1);
        for (int i = 0; i < count; i++) {
            double x = target.getX() + (this.random.nextDouble() - 0.5) * 6.0;
            double z = target.getZ() + (this.random.nextDouble() - 0.5) * 6.0;
            double base = target.getY();
            // go up to 10 blocks, but stop under a ceiling
            double height = 3.0;
            while (height < 10.0 && world.getBlockState(BlockPos.ofFloored(x, base + height + 1.0, z)).isAir()) {
                height++;
            }
            SmallFireballEntity fireball = new SmallFireballEntity(world, this, 0.0, -1.0, 0.0) {
                @Override
                protected void onEntityHit(EntityHitResult hit) {
                    if (this.getWorld().isClient) {
                        return;
                    }
                    Entity victim = hit.getEntity();
                    if (victim instanceof SteveMinionEntity || victim instanceof SteveBossEntity) {
                        return;
                    }
                    if (!victim.isFireImmune()) {
                        victim.setOnFireFor(5);
                    }
                    victim.damage(this.getDamageSources().fireball(this, this.getOwner()), (float) BossConfig.FIREBALL_DAMAGE);
                }
            };
            fireball.setPosition(x, base + height, z);
            world.spawnEntity(fireball);
        }
        world.playSound(null, this.getBlockPos(), SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.HOSTILE, 2.0F, 0.6F);
    }

    /** Teleports the boss to a free spot 3-5 blocks from the player. */
    private void teleportNear(ServerWorld world, PlayerEntity target) {
        for (int attempt = 0; attempt < 10; attempt++) {
            double angle = this.random.nextDouble() * Math.PI * 2.0;
            double dist = 3.0 + this.random.nextDouble() * 2.0;
            double x = target.getX() + Math.cos(angle) * dist;
            double y = target.getY();
            double z = target.getZ() + Math.sin(angle) * dist;
            Box box = this.getBoundingBox().offset(x - this.getX(), y - this.getY(), z - this.getZ());
            if (!world.isSpaceEmpty(this, box) || world.containsFluid(box)) {
                continue;
            }
            world.spawnParticles(ParticleTypes.PORTAL, this.getX(), this.getY() + 1.0, this.getZ(), 40, 0.3, 0.8, 0.3, 0.2);
            world.playSound(null, this.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.HOSTILE, 1.0F, 0.7F);
            this.refreshPositionAfterTeleport(x, y, z);
            this.getNavigation().stop();
            world.spawnParticles(ParticleTypes.PORTAL, x, y + 1.0, z, 40, 0.3, 0.8, 0.3, 0.2);
            world.playSound(null, this.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.HOSTILE, 1.0F, 0.7F);
            return;
        }
    }

    private void keepThunderstorm(ServerWorld world, boolean force) {
        if (force || !world.isThundering()) {
            world.setWeather(0, 24000, true, true);
        }
    }

    private List<SteveMinionEntity> nearbyMinions(ServerWorld world, double radius) {
        Box box = this.getBoundingBox().expand(radius);
        return world.getEntitiesByClass(SteveMinionEntity.class, box, LivingEntity::isAlive);
    }

    private void placeAround(Entity entity) {
        double dx = (this.random.nextDouble() - 0.5) * 6.0;
        double dz = (this.random.nextDouble() - 0.5) * 6.0;
        entity.refreshPositionAndAngles(this.getX() + dx, this.getY(), this.getZ() + dz,
                this.random.nextFloat() * 360.0F, 0.0F);
    }

    private void spawnMinion(ServerWorld world, boolean diamond) {
        SteveMinionEntity minion = ModEntities.STEVE_MINION.create(world);
        if (minion == null) {
            return;
        }
        this.placeAround(minion);
        minion.setDiamond(diamond);
        minion.setTarget(this.getTarget());
        world.spawnEntity(minion);
    }

    /** Phase 1: one Baby Zombie (damage 5) and one Skeleton (damage 5). */
    private void summonPhaseOneHelpers(ServerWorld world) {
        for (int i = 0; i < BossConfig.PHASE1_BABY_ZOMBIES; i++) {
            ZombieEntity zombie = EntityType.ZOMBIE.create(world);
            if (zombie == null) {
                continue;
            }
            this.placeAround(zombie);
            zombie.initialize(world, world.getLocalDifficulty(zombie.getBlockPos()), SpawnReason.MOB_SUMMONED, null, null);
            zombie.setBaby(true);
            MobUtil.setBaseAttackDamage(zombie, BossConfig.HELPER_MOB_DAMAGE);
            // A helmet stops it from burning in daylight
            zombie.equipStack(EquipmentSlot.HEAD, new ItemStack(Items.LEATHER_HELMET));
            zombie.setEquipmentDropChance(EquipmentSlot.HEAD, 0.0F);
            zombie.setTarget(this.getTarget());
            world.spawnEntity(zombie);
        }

        for (int i = 0; i < BossConfig.PHASE1_SKELETONS; i++) {
            SkeletonEntity skeleton = new SkeletonEntity(EntityType.SKELETON, world) {
                @Override
                protected PersistentProjectileEntity createArrowProjectile(ItemStack arrow, float damageModifier) {
                    PersistentProjectileEntity projectile = super.createArrowProjectile(arrow, damageModifier);
                    // Arrow hit damage = ceil(speed(~1.6) * damage) -> about 5
                    projectile.setDamage(BossConfig.HELPER_MOB_DAMAGE / 1.6);
                    return projectile;
                }
            };
            this.placeAround(skeleton);
            skeleton.initialize(world, world.getLocalDifficulty(skeleton.getBlockPos()), SpawnReason.MOB_SUMMONED, null, null);
            MobUtil.setBaseAttackDamage(skeleton, BossConfig.HELPER_MOB_DAMAGE);
            skeleton.equipStack(EquipmentSlot.HEAD, new ItemStack(Items.LEATHER_HELMET));
            skeleton.setEquipmentDropChance(EquipmentSlot.HEAD, 0.0F);
            skeleton.setTarget(this.getTarget());
            world.spawnEntity(skeleton);
        }
    }

    private void broadcast(Text message) {
        if (this.getWorld().getServer() != null) {
            this.getWorld().getServer().getPlayerManager().broadcast(message, false);
        }
    }

    // ------------------------------------------------------------------ boss bar tracking

    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);
        this.bossBar.addPlayer(player);
    }

    @Override
    public void onStoppedTrackingBy(ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        this.bossBar.removePlayer(player);
    }

    // ------------------------------------------------------------------ save / load

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("BossPhase", this.getPhase());
        nbt.putBoolean("IntroDone", this.introDone);
        nbt.putBoolean("Enraged", this.enraged);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        int phase = Math.max(1, Math.min(3, nbt.getInt("BossPhase")));
        if (!nbt.contains("BossPhase")) {
            phase = 1;
        }
        this.dataTracker.set(PHASE, phase);
        this.introDone = nbt.getBoolean("IntroDone");
        this.enraged = nbt.getBoolean("Enraged");
        this.applyPhase(phase, false);
    }
}
