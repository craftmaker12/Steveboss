package com.steveboss.entity;

import com.steveboss.BossConfig;
import com.steveboss.ModEntities;
import com.steveboss.util.MobUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

import java.util.List;

/**
 * Three-phase boss: Steve -> Angry Steve -> HEROBRINE.
 * One entity that "transforms" instead of dying between phases.
 */
public class SteveBossEntity extends HostileEntity {
    private static final TrackedData<Integer> PHASE =
            DataTracker.registerData(SteveBossEntity.class, TrackedDataHandlerRegistry.INTEGER);

    private final ServerBossBar bossBar =
            new ServerBossBar(Text.literal("Steve"), BossBar.Color.GREEN, BossBar.Style.PROGRESS);

    /** Real HP of the phase divided by the (capped) attribute HP. 1.0 unless the phase exceeds 1024 HP. */
    private double damageScale = 1.0;
    private boolean introDone = false;
    private int transitionTicks = 0;
    private int minionTimer = 0;
    private int lightningTimer = 0;
    private int diamondTimer = 0;

    public SteveBossEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 500;
        this.setPersistent();
    }

    public static DefaultAttributeContainer.Builder createBossAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, BossConfig.PHASE1_HEALTH)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, BossConfig.PHASE1_DAMAGE)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.32)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.8);
    }

    // ------------------------------------------------------------------ setup

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new SwimGoal(this));
        this.goalSelector.add(2, new MeleeAttackGoal(this, 1.1, false));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.8));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 12.0F));
        this.goalSelector.add(7, new LookAroundGoal(this));
        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    protected void initDataTracker() {
        super.initDataTracker();
        this.dataTracker.startTracking(PHASE, 1);
    }

    public int getPhase() {
        return this.dataTracker.get(PHASE);
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }

    // ------------------------------------------------------------------ phases

    private static String phaseName(int phase) {
        return switch (phase) {
            case 1 -> "Steve";
            case 2 -> "Angry Steve";
            default -> "HEROBRINE";
        };
    }

    /**
     * Applies health / damage / equipment / name of a phase.
     *
     * @param heal true on a real transition (refill HP), false when loading from disk
     */
    private void applyPhase(int phase, boolean heal) {
        double realHealth;
        double damage;
        Formatting color;
        BossBar.Color barColor;
        switch (phase) {
            case 1 -> {
                realHealth = BossConfig.PHASE1_HEALTH;
                damage = BossConfig.PHASE1_DAMAGE;
                color = Formatting.GREEN;
                barColor = BossBar.Color.GREEN;
            }
            case 2 -> {
                realHealth = BossConfig.PHASE2_HEALTH;
                damage = BossConfig.PHASE2_DAMAGE;
                color = Formatting.GOLD;
                barColor = BossBar.Color.YELLOW;
            }
            default -> {
                realHealth = BossConfig.PHASE3_HEALTH;
                damage = BossConfig.PHASE3_DAMAGE;
                color = Formatting.DARK_RED;
                barColor = BossBar.Color.RED;
            }
        }

        // Vanilla clamps max health to 1024, so anything above is emulated by scaling incoming damage.
        double attributeHealth = Math.min(realHealth, BossConfig.VANILLA_MAX_HEALTH_CAP);
        this.damageScale = attributeHealth / realHealth;
        EntityAttributeInstance maxHealth = this.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        if (maxHealth != null) {
            maxHealth.setBaseValue(attributeHealth);
        }
        if (heal) {
            this.setHealth((float) attributeHealth);
        }

        if (phase >= 3) {
            ItemStack sword = new ItemStack(Items.NETHERITE_SWORD);
            this.equipStack(EquipmentSlot.MAINHAND, sword);
            MobUtil.setExactAttackDamage(this, sword, damage);
        } else {
            this.equipStack(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            MobUtil.setBaseAttackDamage(this, damage);
        }
        this.setEquipmentDropChance(EquipmentSlot.MAINHAND, 0.0F);

        Text name = Text.literal(phaseName(phase)).formatted(color, Formatting.BOLD);
        this.setCustomName(name);
        this.setCustomNameVisible(true);
        this.bossBar.setName(name);
        this.bossBar.setColor(barColor);
    }

    private void advancePhase() {
        int next = this.getPhase() + 1;
        this.dataTracker.set(PHASE, next);
        this.applyPhase(next, true);
        this.transitionTicks = 40; // 2 seconds of invulnerability
        this.minionTimer = 0;
        this.lightningTimer = 60;
        this.diamondTimer = 100;
        this.setTarget(this.getTarget());

        if (this.getWorld() instanceof ServerWorld world) {
            world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, this.getX(), this.getY() + 1.0, this.getZ(),
                    1, 0.0, 0.0, 0.0, 0.0);
            world.playSound(null, this.getBlockPos(), SoundEvents.ENTITY_WITHER_SPAWN, SoundCategory.HOSTILE,
                    2.0F, next == 3 ? 0.5F : 1.0F);

            if (next == 2) {
                this.spawnMinion(world, false); // Steve Minion with Stone Sword
            } else if (next == 3) {
                this.keepThunderstorm(world, true);
                world.playSound(null, this.getBlockPos(), SoundEvents.ENTITY_ENDER_DRAGON_GROWL,
                        SoundCategory.HOSTILE, 3.0F, 0.6F);
                this.broadcast(Text.literal("Steve has turned into HEROBRINE!").formatted(Formatting.DARK_RED, Formatting.BOLD));

                // "Get ready": Strength for nearby players
                double radius = BossConfig.PHASE3_STRENGTH_RADIUS;
                for (ServerPlayerEntity player : world.getPlayers(
                        p -> p.isAlive() && !p.isSpectator() && p.squaredDistanceTo(this) <= radius * radius)) {
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH,
                            BossConfig.PHASE3_STRENGTH_SECONDS * 20, BossConfig.PHASE3_STRENGTH_AMPLIFIER,
                            false, false, true));
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE,
                            BossConfig.PHASE3_RESISTANCE_SECONDS * 20, BossConfig.PHASE3_RESISTANCE_AMPLIFIER,
                            false, false, true));
                    player.sendMessage(Text.literal("Get ready! Strength + Resistance")
                            .formatted(Formatting.GOLD, Formatting.BOLD), true);
                }
            }
        }
    }

    // ------------------------------------------------------------------ damage / death

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (this.getWorld().isClient) {
            return super.damage(source, amount);
        }
        // /kill, void, etc. go straight through.
        if (source.isIn(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return super.damage(source, amount);
        }
        if (this.transitionTicks > 0) {
            return false;
        }

        float scaled = (float) (amount * this.damageScale);
        if (this.getPhase() < 3 && scaled >= this.getHealth()) {
            // Would die -> transform into the next phase instead.
            this.advancePhase();
            return true;
        }
        return super.damage(source, scaled);
    }

    @Override
    public void onStruckByLightning(ServerWorld world, LightningEntity lightning) {
        // Herobrine is immune to his own lightning.
    }

    @Override
    public void onDeath(DamageSource source) {
        super.onDeath(source);
        if (!(this.getWorld() instanceof ServerWorld world)) {
            return;
        }
        this.bossBar.clearPlayers();

        // Remove leftover minions
        for (SteveMinionEntity minion : this.nearbyMinions(world, 80.0)) {
            minion.kill();
        }

        PlayerEntity killer = null;
        Entity attacker = source.getAttacker();
        if (attacker instanceof PlayerEntity player) {
            killer = player;
        } else if (this.getAttacker() instanceof PlayerEntity lastPlayer) {
            killer = lastPlayer;
        }

        Text title = Text.literal(phaseName(this.getPhase())).formatted(Formatting.DARK_RED, Formatting.BOLD);
        if (killer != null) {
            this.broadcast(Text.empty()
                    .append(title)
                    .append(Text.literal(" was defeated by ").formatted(Formatting.GRAY))
                    .append(killer.getDisplayName().copy().formatted(Formatting.GOLD, Formatting.BOLD))
                    .append(Text.literal("!").formatted(Formatting.GRAY)));
        } else {
            this.broadcast(Text.empty()
                    .append(title)
                    .append(Text.literal(" has been defeated!").formatted(Formatting.GRAY)));
        }

        if (this.getPhase() >= 3) {
            world.setWeather(6000, 0, false, false); // stop the storm
        }
    }

    @Override
    public void remove(RemovalReason reason) {
        if (!this.getWorld().isClient) {
            this.bossBar.clearPlayers();
            if (this.getPhase() >= 3 && this.getWorld() instanceof ServerWorld world
                    && (reason == RemovalReason.KILLED || reason == RemovalReason.DISCARDED)) {
                world.setWeather(6000, 0, false, false);
            }
        }
        super.remove(reason);
    }

    // ------------------------------------------------------------------ tick

    @Override
    protected void mobTick() {
        super.mobTick();
        if (!(this.getWorld() instanceof ServerWorld world)) {
            return;
        }
        this.bossBar.setPercent(this.getHealth() / this.getMaxHealth());

        if (this.transitionTicks > 0) {
            this.transitionTicks--;
        }

        int phase = this.getPhase();

        if (!this.introDone) {
            this.introDone = true;
            if (phase == 1) {
                this.summonPhaseOneHelpers(world);
            }
        }

        if (phase == 2) {
            if (++this.minionTimer >= 500 && this.nearbyMinions(world, 40.0).size() < BossConfig.MAX_MINIONS_ALIVE) {
                this.minionTimer = 0;
                this.spawnMinion(world, false);
            }
        }

        if (phase >= 3) {
            if (this.age % 100 == 0) {
                this.keepThunderstorm(world, false);
            }

            LivingEntity target = this.getTarget();
            if (target instanceof PlayerEntity player && player.isAlive() && !player.isSpectator()) {
                // Ability 1: lightning bolt on the player
                if (++this.lightningTimer >= BossConfig.LIGHTNING_INTERVAL_TICKS) {
                    this.lightningTimer = 0;
                    LightningEntity bolt = net.minecraft.entity.EntityType.LIGHTNING_BOLT.create(world);
                    if (bolt != null) {
                        bolt.refreshPositionAfterTeleport(player.getPos());
                        world.spawnEntity(bolt);
                    }
                }
                // Ability 2: Steve Minion with Diamond Sword
                if (++this.diamondTimer >= BossConfig.DIAMOND_MINION_INTERVAL_TICKS) {
                    this.diamondTimer = 0;
                    if (this.nearbyMinions(world, 40.0).size() < BossConfig.MAX_MINIONS_ALIVE) {
                        this.spawnMinion(world, true);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ helpers

    private void keepThunderstorm(ServerWorld world, boolean force) {
        if (force || !world.isThundering()) {
            world.setWeather(0, 24000, true, true);
        }
    }

    private List<SteveMinionEntity> nearbyMinions(ServerWorld world, double radius) {
        Box box = this.getBoundingBox().expand(radius);
        return world.getEntitiesByClass(SteveMinionEntity.class, box, LivingEntity::isAlive);
    }

    private void placeAround(Entity entity) {
        double dx = (this.random.nextDouble() - 0.5) * 6.0;
        double dz = (this.random.nextDouble() - 0.5) * 6.0;
        entity.refreshPositionAndAngles(this.getX() + dx, this.getY(), this.getZ() + dz,
                this.random.nextFloat() * 360.0F, 0.0F);
    }

    private void spawnMinion(ServerWorld world, boolean diamond) {
        SteveMinionEntity minion = ModEntities.STEVE_MINION.create(world);
        if (minion == null) {
            return;
        }
        this.placeAround(minion);
        minion.setDiamond(diamond);
        minion.setTarget(this.getTarget());
        world.spawnEntity(minion);
    }

    /** Phase 1: one Baby Zombie (damage 5) and one Skeleton (damage 5). */
    private void summonPhaseOneHelpers(ServerWorld world) {
        for (int i = 0; i < BossConfig.PHASE1_BABY_ZOMBIES; i++) {
            ZombieEntity zombie = EntityType.ZOMBIE.create(world);
            if (zombie == null) {
                continue;
            }
            this.placeAround(zombie);
            zombie.initialize(world, world.getLocalDifficulty(zombie.getBlockPos()), SpawnReason.MOB_SUMMONED, null, null);
            zombie.setBaby(true);
            MobUtil.setBaseAttackDamage(zombie, BossConfig.HELPER_MOB_DAMAGE);
            // A helmet stops it from burning in daylight
            zombie.equipStack(EquipmentSlot.HEAD, new ItemStack(Items.LEATHER_HELMET));
            zombie.setEquipmentDropChance(EquipmentSlot.HEAD, 0.0F);
            zombie.setTarget(this.getTarget());
            world.spawnEntity(zombie);
        }

        for (int i = 0; i < BossConfig.PHASE1_SKELETONS; i++) {
            SkeletonEntity skeleton = new SkeletonEntity(EntityType.SKELETON, world) {
                @Override
                protected PersistentProjectileEntity createArrowProjectile(ItemStack arrow, float damageModifier) {
                    PersistentProjectileEntity projectile = super.createArrowProjectile(arrow, damageModifier);
                    // Arrow hit damage = ceil(speed(~1.6) * damage) -> about 5
                    projectile.setDamage(BossConfig.HELPER_MOB_DAMAGE / 1.6);
                    return projectile;
                }
            };
            this.placeAround(skeleton);
            skeleton.initialize(world, world.getLocalDifficulty(skeleton.getBlockPos()), SpawnReason.MOB_SUMMONED, null, null);
            MobUtil.setBaseAttackDamage(skeleton, BossConfig.HELPER_MOB_DAMAGE);
            skeleton.equipStack(EquipmentSlot.HEAD, new ItemStack(Items.LEATHER_HELMET));
            skeleton.setEquipmentDropChance(EquipmentSlot.HEAD, 0.0F);
            skeleton.setTarget(this.getTarget());
            world.spawnEntity(skeleton);
        }
    }

    private void broadcast(Text message) {
        if (this.getWorld().getServer() != null) {
            this.getWorld().getServer().getPlayerManager().broadcast(message, false);
        }
    }

    // ------------------------------------------------------------------ boss bar tracking

    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);
        this.bossBar.addPlayer(player);
    }

    @Override
    public void onStoppedTrackingBy(ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        this.bossBar.removePlayer(player);
    }

    // ------------------------------------------------------------------ save / load

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("BossPhase", this.getPhase());
        nbt.putBoolean("IntroDone", this.introDone);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        int phase = Math.max(1, Math.min(3, nbt.getInt("BossPhase")));
        if (!nbt.contains("BossPhase")) {
            phase = 1;
        }
        this.dataTracker.set(PHASE, phase);
        this.introDone = nbt.getBoolean("IntroDone");
        this.applyPhase(phase, false);
    }
}
