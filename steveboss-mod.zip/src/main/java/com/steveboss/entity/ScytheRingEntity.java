package com.steveboss.entity;

import com.steveboss.BossConfig;
import com.steveboss.ModEntities;
import com.steveboss.ModItems;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.thrown.ThrownItemEntity;
import net.minecraft.item.Item;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.HashSet;
import java.util.Set;

/**
 * The red ring thrown by the Crimson Scythe. It flies forward, hurts everything it touches,
 * then comes back to the thrower like a boomerang (and hurts everything again on the way back).
 */
public class ScytheRingEntity extends ThrownItemEntity {
    private static final int OUTBOUND_TICKS = 14;
    private static final int MAX_LIFETIME_TICKS = 100;

    private boolean returning = false;
    private final Set<Integer> alreadyHit = new HashSet<>();

    public ScytheRingEntity(EntityType<? extends ScytheRingEntity> type, World world) {
        super(type, world);
    }

    public ScytheRingEntity(World world, LivingEntity owner) {
        super(ModEntities.SCYTHE_RING, owner, world);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.SCYTHE_RING;
    }

    @Override
    protected float getGravity() {
        return 0.0F; // flies straight
    }

    private void startReturning() {
        this.returning = true;
        this.alreadyHit.clear(); // it can hurt the same targets again on the way back
    }

    @Override
    public void tick() {
        super.tick();
        if (!(this.getWorld() instanceof ServerWorld world)) {
            return;
        }
        world.spawnParticles(ParticleTypes.CRIT, this.getX(), this.getY(), this.getZ(), 3, 0.2, 0.2, 0.2, 0.05);

        if (!this.returning && this.age >= OUTBOUND_TICKS) {
            this.startReturning();
        }
        if (this.returning) {
            Entity owner = this.getOwner();
            if (owner == null || !owner.isAlive() || this.age > MAX_LIFETIME_TICKS) {
                this.discard();
                return;
            }
            Vec3d toOwner = owner.getPos().add(0.0, owner.getHeight() * 0.6, 0.0).subtract(this.getPos());
            if (toOwner.length() < 1.5) {
                this.discard();
                return;
            }
            this.setVelocity(toOwner.normalize().multiply(1.4));
        }
    }

    @Override
    protected void onEntityHit(EntityHitResult hit) {
        Entity owner = this.getOwner();
        Entity target = hit.getEntity();
        if (target == owner || !(target instanceof LivingEntity living) || !this.alreadyHit.add(target.getId())) {
            return;
        }
        living.damage(this.getDamageSources().thrown(this, owner), (float) BossConfig.SCYTHE_RING_DAMAGE);
        living.setOnFireFor(4);
        living.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 100, 1), owner);
        if (owner instanceof LivingEntity thrower) {
            thrower.heal((float) (BossConfig.SCYTHE_RING_DAMAGE * BossConfig.SCYTHE_LIFESTEAL));
        }
    }

    @Override
    protected void onBlockHit(BlockHitResult hit) {
        // Hitting a wall sends it back
        if (!this.returning) {
            this.startReturning();
        }
    }
}
