package com.steveboss.entity;

import com.steveboss.BossConfig;
import com.steveboss.util.MobUtil;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.world.World;

/**
 * A small Steve that carries either a Stone Sword (damage 5) or a Diamond Sword (damage 10).
 */
public class SteveMinionEntity extends HostileEntity {
    private static final TrackedData<Boolean> DIAMOND =
            DataTracker.registerData(SteveMinionEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

    public SteveMinionEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 10;
    }

    public static DefaultAttributeContainer.Builder createMinionAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 30.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, BossConfig.STONE_MINION_DAMAGE)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 40.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new SwimGoal(this));
        this.goalSelector.add(2, new MeleeAttackGoal(this, 1.1, false));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.8));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8.0F));
        this.goalSelector.add(7, new LookAroundGoal(this));
        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    protected void initDataTracker() {
        super.initDataTracker();
        this.dataTracker.startTracking(DIAMOND, false);
    }

    public boolean isDiamond() {
        return this.dataTracker.get(DIAMOND);
    }

    /** Equips the sword and sets the exact total damage (stone = 5, diamond = 10). */
    public void setDiamond(boolean diamond) {
        this.dataTracker.set(DIAMOND, diamond);
        ItemStack sword = new ItemStack(diamond ? Items.DIAMOND_SWORD : Items.STONE_SWORD);
        this.equipStack(EquipmentSlot.MAINHAND, sword);
        this.setEquipmentDropChance(EquipmentSlot.MAINHAND, 0.0F);
        MobUtil.setExactAttackDamage(this, sword,
                diamond ? BossConfig.DIAMOND_MINION_DAMAGE : BossConfig.STONE_MINION_DAMAGE);
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putBoolean("Diamond", this.isDiamond());
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        // Equipment and attributes are restored by the superclass; only the synced flag is needed.
        this.dataTracker.set(DIAMOND, nbt.getBoolean("Diamond"));
    }
}
