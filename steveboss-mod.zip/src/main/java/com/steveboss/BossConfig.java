package com.steveboss;

/**
 * All tunable numbers of the boss fight in one place.
 */
public final class BossConfig {
    private BossConfig() {
    }

    // ---- Phase 1: Steve ----
    public static final double PHASE1_HEALTH = 1000.0;
    public static final double PHASE1_DAMAGE = 5.0;
    public static final int PHASE1_BABY_ZOMBIES = 1;
    public static final int PHASE1_SKELETONS = 1;
    public static final double HELPER_MOB_DAMAGE = 5.0; // Baby Zombie + Skeleton

    // ---- Phase 2: Error 404 ----
    public static final double PHASE2_HEALTH = 3500.0;
    public static final double PHASE2_DAMAGE = 6.0;
    public static final int PHASE2_MINIONS = 1;          // Steve Minion with Stone Sword
    public static final double STONE_MINION_DAMAGE = 5.0;

    // ---- Phase 3: HEROBRINE ----
    public static final double PHASE3_HEALTH = 5780.0;
    public static final double PHASE3_DAMAGE = 10.0;
    public static final double DIAMOND_MINION_DAMAGE = 10.0;
    public static final int LIGHTNING_INTERVAL_TICKS = 160;        // ~8 seconds
    public static final int DIAMOND_MINION_INTERVAL_TICKS = 300;   // ~15 seconds
    public static final int MAX_MINIONS_ALIVE = 4;
    public static final int TELEPORT_INTERVAL_TICKS = 200;         // ~10 seconds
    public static final int FIREBALL_INTERVAL_TICKS = 140;         // ~7 seconds
    public static final int FIREBALL_COUNT = 4;                    // fireballs per volley
    public static final double FIREBALL_DAMAGE = 7.0;
    public static final int SONIC_BOOM_INTERVAL_TICKS = 180;       // ~9 seconds
    public static final double SONIC_BOOM_DAMAGE = 10.0;           // same as the Warden
    public static final double SONIC_BOOM_RANGE = 30.0;

    // TNT drop: a TNT falls on the player, then explodes hugely
    public static final int TNT_INTERVAL_TICKS = 300;              // ~15 seconds
    public static final int TNT_FUSE_TICKS = 40;                   // 2 seconds of warning
    public static final double TNT_EXPLOSION_RADIUS = 50.0;        // everything within this radius takes damage
    public static final double TNT_DAMAGE = 19.0;
    public static final int TNT_BLOCK_RADIUS = 5;                  // crater radius (0 = no block damage)

    // Rage mode: HEROBRINE below this fraction of his health
    public static final double RAGE_HEALTH_FRACTION = 0.5;         // 50%
    public static final int RAGE_ABILITY_SPEEDUP = 3;               // every ability recharges 3x faster
    public static final double RAGE_FLY_SPEED = 0.6;               // blocks per tick while flying (12 blocks/second)
    public static final double RAGE_MOVEMENT_SPEED = 0.6;          // ground speed attribute (normal: 0.32)
    public static final double RAGE_ATTACK_DAMAGE = 11.0;          // melee damage while enraged (normal: PHASE3_DAMAGE)
    public static final int RAGE_FIREBALL_MULTIPLIER = 2;          // fireballs per volley x2
    public static final int RAGE_TNT_COUNT = 2;                    // TNTs per drop (staggered by 1 second)
    public static final double RAGE_TNT_DAMAGE = 12.0;             // TNT explosion damage while enraged (normal: TNT_DAMAGE)
    public static final int RAGE_SONIC_BEAMS = 1;                  // sonic boom beams (fan)
    public static final double RAGE_SONIC_BOOM_DAMAGE = 8.0;       // per beam while enraged (normal: SONIC_BOOM_DAMAGE)

    // Crimson Scythe
    public static final double SCYTHE_LIFESTEAL = 0.10;            // 10% of the damage comes back as health
    public static final double SCYTHE_RING_DAMAGE = 20.0;          // thrown ring, each pass
    public static final double SCYTHE_SPIN_DAMAGE = 25.0;          // spin attack
    public static final double SCYTHE_SPIN_RADIUS = 5.0;

    // Crystal Bow: a full-draw shot also fires a sonic boom
    public static final double BOW_SONIC_BOOM_DAMAGE = 20.0;
    public static final double BOW_SONIC_BOOM_RANGE = 24.0;

    // Buff given to nearby players when Steve turns into Error 404 (phase 2).
    // Same as: /effect give <player> health_boost 200 35 true
    //          /effect give <player> resistance 35 40 true
    //          /effect give <player> strength 100 34 true
    public static final int PHASE2_HEALTH_BOOST_SECONDS = 200;
    public static final int PHASE2_HEALTH_BOOST_AMPLIFIER = 35;  // level 36 (+144 HP)
    public static final int PHASE2_RESISTANCE_SECONDS = 35; 
    public static final int PHASE2_RESISTANCE_AMPLIFIER = 40;    // level 41
    public static final int PHASE2_STRENGTH_SECONDS = 100;
    public static final int PHASE2_STRENGTH_AMPLIFIER = 34;      // level 35
    public static final double PHASE2_BUFF_RADIUS = 64.0;

    // Shotgun: given to the players near the boss at the start of phase 2, together with its ammo
    public static final double SHOTGUN_DAMAGE = 41.0;
    public static final double SHOTGUN_RANGE = 64.0;
    public static final int SHOTGUN_COOLDOWN_TICKS = 20;
    public static final int SHOTGUN_AMMO_GIVEN = 200;

    // Reward given to the player who kills HEROBRINE
    public static final int REWARD_DIAMOND_BLOCKS = 60;
    public static final int REWARD_DRAGON_EGGS = 5;
    public static final int REWARD_NETHERITE_BLOCKS = 20;
    public static final int REWARD_FIREWORKS = 67;
    public static final int REWARD_FIREWORK_FLIGHT = 3;           // flight duration of the rockets

    /** Minecraft clamps the max-health attribute to this value. */
    public static final double VANILLA_MAX_HEALTH_CAP = 1024.0;
}
