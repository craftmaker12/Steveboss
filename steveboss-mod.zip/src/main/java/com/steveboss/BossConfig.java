package com.steveboss;

/**
 * All tunable numbers of the boss fight in one place.
 */
public final class BossConfig {
    private BossConfig() {
    }

    // ---- Phase 1: Steve ----
    public static final double PHASE1_HEALTH = 700.0;
    public static final double PHASE1_DAMAGE = 5.0;
    public static final int PHASE1_BABY_ZOMBIES = 1;
    public static final int PHASE1_SKELETONS = 1;
    public static final double HELPER_MOB_DAMAGE = 5.0; // Baby Zombie + Skeleton

    // ---- Phase 2: Angry Steve ----
    public static final double PHASE2_HEALTH = 1000.0;
    public static final double PHASE2_DAMAGE = 6.0;
    public static final int PHASE2_MINIONS = 1;          // Steve Minion with Stone Sword
    public static final double STONE_MINION_DAMAGE = 5.0;

    // ---- Phase 3: HEROBRINE ----
    public static final double PHASE3_HEALTH = 5600.0;
    public static final double PHASE3_DAMAGE = 10.0;
    public static final double DIAMOND_MINION_DAMAGE = 10.0;
    public static final int LIGHTNING_INTERVAL_TICKS = 160;        // ~8 seconds
    public static final int DIAMOND_MINION_INTERVAL_TICKS = 300;   // ~15 seconds
    public static final int MAX_MINIONS_ALIVE = 4;

    // Buff given to nearby players when Angry Steve falls and HEROBRINE appears
    // (same as: /effect give <player> strength 40 39 true  and  /effect give <player> resistance 45 42 true)
    public static final int PHASE3_STRENGTH_SECONDS = 40;
    public static final int PHASE3_STRENGTH_AMPLIFIER = 39;    // level 40
    public static final int PHASE3_RESISTANCE_SECONDS = 45;
    public static final int PHASE3_RESISTANCE_AMPLIFIER = 42;  // level 43
    public static final double PHASE3_STRENGTH_RADIUS = 64.0;

    // Reward given to the player who kills HEROBRINE
    public static final int REWARD_DIAMOND_BLOCKS = 60;
    public static final int REWARD_DRAGON_EGGS = 5;
    public static final int REWARD_NETHERITE_BLOCKS = 20;

    /** Minecraft clamps the max-health attribute to this value. */
    public static final double VANILLA_MAX_HEALTH_CAP = 1024.0;
}
