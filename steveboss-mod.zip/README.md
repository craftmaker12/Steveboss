# Steve Boss (Fabric 1.20.1)

3-phase boss: **Steve → Error 404 → HEROBRINE**.

| Phase | HP | Damage | Extras |
|---|---|---|---|
| 1 Steve | 1000 | 5 | Summons a Baby Zombie (5) + Skeleton (5) on spawn |
| 2 Error 404 | 3500 | 6 | Summons Steve Minion with Stone Sword (5) |
| 3 HEROBRINE | 5780 | 10 (Netherite Sword) | Thunderstorm, lightning on the player, Steve Minion with Diamond Sword (10). On death: chat message with the killer's name + storm stops |

## Summoning ritual
1. Build a 3x3 platform of **Blue Concrete**.
2. Put one **Cyan Concrete** block on the middle of it.
3. Stand at least **3 Torches** on the platform around the Cyan block.
4. Right-click the top of the Cyan block with **Flint and Steel**.

Other ways: Creative → **Spawn Eggs** tab, or `/summon steveboss:steve_boss`.
Tunable numbers: `src/main/java/com/steveboss/BossConfig.java`.

## Versions
Minecraft 1.20.1 · Java 17 · Gradle 8.5 · Fabric Loom 1.5 · Fabric Loader 0.15.11 · Fabric API 0.92.2+1.20.1

## Build on GitHub
1. Push this folder to a GitHub repo (the `.github` folder must be at the repo root).
2. Open **Actions → Build → Run workflow** (it also runs on every push).
3. Download the jar from **Artifacts → steveboss-mod-jar**. Use `steveboss-1.0.0.jar` (not `-sources`).
4. Put it in `mods/` together with Fabric API 0.92.2+1.20.1.

## Build locally
Install JDK 17 + Gradle 8.5, then `gradle build`. The jar is in `build/libs/`.
